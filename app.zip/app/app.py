
import streamlit as st
import pandas as pd
import joblib
import json
import numpy as np
import shap
import matplotlib.pyplot as plt

# Load models and assets
model = joblib.load('model.pkl')
scaler = joblib.load('scaler.pkl')
with open('feature_names.json', 'r') as f:
    feature_names = json.load(f)
with open('test_patient.json', 'r') as f:
    test_patient_data = json.load(f)

st.set_page_config(layout='centered', page_title='Heart Disease Predictor')

st.title('Heart Disease Prediction Dashboard')
st.write('---')

st.header('Enter Patient Data:')

# Create input fields for each feature
input_dict = {}

# Group features by type for better input handling
# Continuous features
CONT_COLS = ['age', 'trestbps', 'chol', 'thalach', 'oldpeak', 'ca']
# Binary features
BINARY_COLS = ['sex', 'fbs', 'exang']
# Categorical features that were one-hot encoded
CAT_PREFIXES = {
    'cp': ['cp_1.0', 'cp_2.0', 'cp_3.0', 'cp_4.0'],
    'restecg': ['restecg_0.0', 'restecg_1.0', 'restecg_2.0'],
    'slope': ['slope_1.0', 'slope_2.0', 'slope_3.0'],
    'thal': ['thal_3.0', 'thal_6.0', 'thal_7.0']
}

# Helper function to inverse transform scaled continuous features for pre-filling
def inverse_transform_continuous(scaled_value, feature_name, scaler_obj, feature_names_list, cont_cols_list):
    # Create a dummy dataframe with zeros for all features
    dummy_input = pd.DataFrame(0.0, index=[0], columns=feature_names_list)

    # Temporarily set the value of the specific continuous feature in the dummy input
    if feature_name in cont_cols_list:
        dummy_input.loc[0, feature_name] = scaled_value

        # Create a temporary array for inverse scaling, with only the feature of interest scaled
        temp_scaled_data = np.zeros((1, len(cont_cols_list)))
        cont_col_index = cont_cols_list.index(feature_name)
        temp_scaled_data[0, cont_col_index] = scaled_value

        # Inverse transform only the relevant continuous column
        inverted_value = scaler_obj.inverse_transform(temp_scaled_data)[0, cont_col_index]
        return inverted_value
    return scaled_value # Return as is if not a continuous feature or no inverse needed

# Extract original values for pre-filling (requires careful handling of scaled and one-hot encoded features)
prefill_data = {}
for k, v in test_patient_data.items():
    if k in CONT_COLS:
        # Pass the actual scaler object and feature names for correct inverse transformation
        prefill_data[k] = inverse_transform_continuous(v, k, scaler, feature_names, CONT_COLS)
    elif k.startswith('cp_') and v == True: # Use True for boolean in JSON
        prefill_data['cp'] = float(k.split('_')[1])
    elif k.startswith('restecg_') and v == True:
        prefill_data['restecg'] = float(k.split('_')[1])
    elif k.startswith('slope_') and v == True:
        prefill_data['slope'] = float(k.split('_')[1])
    elif k.startswith('thal_') and v == True:
        prefill_data['thal'] = float(k.split('_')[1])
    elif k == 'sex' or k == 'fbs' or k == 'exang':
        prefill_data[k] = int(v) # These are 0/1 represented as float in original X_test

col1, col2, col3 = st.columns(3)

# Input for Continuous features
with col1:
    st.subheader('Continuous Features')
    input_dict['age'] = st.slider('Age (years)', 29, 77, int(prefill_data.get('age', 50)), help='Age in years (29-77)')
    input_dict['trestbps'] = st.slider('Resting Blood Pressure (mm Hg)', 94, 200, int(prefill_data.get('trestbps', 130)), help='Resting blood pressure in mm Hg (94-200)')
    input_dict['chol'] = st.slider('Cholesterol (mg/dl)', 126, 564, int(prefill_data.get('chol', 240)), help='Serum cholestoral in mg/dl (126-564)')

with col2:
    st.subheader('Continuous Features (cont.)')
    input_dict['thalach'] = st.slider('Max Heart Rate achieved (bpm)', 71, 202, int(prefill_data.get('thalach', 150)), help='Maximum heart rate achieved (71-202 bpm)')
    input_dict['oldpeak'] = st.slider('ST depression induced by exercise (oldpeak)', 0.0, 6.2, float(prefill_data.get('oldpeak', 1.0)), step=0.1, help='ST depression induced by exercise relative to rest (0.0-6.2)')
    input_dict['ca'] = st.slider('Number of Major Vessels colored by fluoroscopy (0-3)', 0, 3, int(prefill_data.get('ca', 0)), help='Number of major vessels (0-3) colored by fluoroscopy')

with col3:
    st.subheader('Binary & Categorical Features')
    input_dict['sex'] = st.selectbox('Sex', [0, 1], index=prefill_data.get('sex', 1), format_func=lambda x: 'Male' if x == 1 else 'Female', help='1 = male; 0 = female')
    input_dict['fbs'] = st.selectbox('Fasting Blood Sugar > 120 mg/dl', [0, 1], index=prefill_data.get('fbs', 0), format_func=lambda x: 'True' if x == 1 else 'False', help='(fasting blood sugar > 120 mg/dl) (1 = true; 0 = false)')
    input_dict['exang'] = st.selectbox('Exercise Induced Angina', [0, 1], index=prefill_data.get('exang', 0), format_func=lambda x: 'Yes' if x == 1 else 'No', help='Exercise induced angina (1 = yes; 0 = no)')

    # Input for one-hot encoded categorical features
    cp_options = [1.0, 2.0, 3.0, 4.0]
    cp_option = st.selectbox('Chest Pain Type (cp)', cp_options, index=cp_options.index(prefill_data.get('cp', 1.0)), help='1: typical angina; 2: atypical angina; 3: non-anginal pain; 4: asymptomatic')

    restecg_options = [0.0, 1.0, 2.0]
    restecg_option = st.selectbox('Resting Electrocardiographic Results (restecg)', restecg_options, index=restecg_options.index(prefill_data.get('restecg', 0.0)), help='0: normal; 1: ST-T wave abnormality; 2: left ventricular hypertrophy')

    slope_options = [1.0, 2.0, 3.0]
    slope_option = st.selectbox('Slope of the Peak Exercise ST Segment (slope)', slope_options, index=slope_options.index(prefill_data.get('slope', 1.0)), help='1: upsloping; 2: flat; 3: downsloping')

    thal_options = [3.0, 6.0, 7.0]
    thal_option = st.selectbox('Thalassemia (thal)', thal_options, index=thal_options.index(prefill_data.get('thal', 3.0)), help='3: normal; 6: fixed defect; 7: reversible defect')

# Create a DataFrame from the input
input_df = pd.DataFrame([input_dict])

# Apply one-hot encoding for categorical features based on selected options
for prefix, cols in CAT_PREFIXES.items():
    for col in cols:
        input_df[col] = 0 # Initialize all one-hot columns to 0
    if prefix == 'cp':
        input_df[f'cp_{cp_option}'] = 1
    elif prefix == 'restecg':
        input_df[f'restecg_{restecg_option}'] = 1
    elif prefix == 'slope':
        input_df[f'slope_{slope_option}'] = 1
    elif prefix == 'thal':
        input_df[f'thal_{thal_option}'] = 1

# Ensure all feature_names are present and in the correct order
# Fill any missing one-hot encoded columns with 0
final_input_data = pd.DataFrame(0, index=[0], columns=feature_names)
for col in input_df.columns:
    if col in final_input_data.columns:
        final_input_data[col] = input_df[col].values[0]

# Convert boolean columns to integer 0/1 for scaling if necessary
for col in final_input_data.columns:
    if final_input_data[col].dtype == 'bool':
        final_input_data[col] = final_input_data[col].astype(int)

# Scale continuous features
scaled_continuous_data = scaler.transform(final_input_data[CONT_COLS])
final_input_data[CONT_COLS] = scaled_continuous_data

# Prediction button
if st.button('Predict Heart Disease Risk'):
    # Make prediction
    prediction_proba = model.predict_proba(final_input_data)[:, 1][0]
    prediction = (prediction_proba > 0.5).astype(int)

    st.subheader('Prediction:')
    if prediction == 1:
        st.markdown(f'### <span style="color:red">High Risk of Heart Disease</span> (Probability: {prediction_proba:.2%})', unsafe_allow_html=True)
    else:
        st.markdown(f'### <span style="color:green">Low Risk of Heart Disease</span> (Probability: {prediction_proba:.2%})', unsafe_allow_html=True)

    # SHAP explanation
    explainer = shap.TreeExplainer(model)
    shap_values = explainer.shap_values(final_input_data)

    # Get absolute SHAP values for importance ranking
    # For binary classification, shap_values is a list of two arrays. [0] for class 0, [1] for class 1
    # We need to decide which class's SHAP values to display. Typically, for the predicted class.
    # If prediction is 1 (disease), we use shap_values[1], otherwise shap_values[0]
    if isinstance(shap_values, list):
        shap_values_to_plot = shap_values[1] if prediction == 1 else shap_values[0]
    else: # For models like linear models, shap_values might be a single array
        shap_values_to_plot = shap_values

    # Associate SHAP values with feature names and sort
    shap_df = pd.DataFrame({
        'feature': final_input_data.columns,
        'shap_value': shap_values_to_plot
    })
    shap_df['abs_shap_value'] = np.abs(shap_df['shap_value'])
    shap_df = shap_df.sort_values(by='abs_shap_value', ascending=False).head(3)

    st.subheader('Top 3 Features Driving the Prediction:')
    fig, ax = plt.subplots(figsize=(8, 3))
    # Color based on whether SHAP value is positive (contributes to higher risk) or negative
    colors = ['#d62728' if val > 0 else '#2ca02c' for val in shap_df['shap_value']] # Red for positive SHAP, Green for negative SHAP
    ax.barh(shap_df['feature'], shap_df['abs_shap_value'], color=colors)
    ax.set_xlabel('Absolute SHAP Value')
    ax.set_ylabel('Feature')
    ax.set_yticklabels(shap_df['feature'], ha='right') # Align labels right
    ax.invert_yaxis() # Highest importance at the top
    st.pyplot(fig)

    # Plain-English Explanation
    st.subheader('Clinical Interpretation:')
    explanation_phrases = []
    for i, row in shap_df.iterrows():
        feature_name = row['feature']
        display_name = feature_name # Default display name

        # Map one-hot encoded features back to their original categorical names
        for prefix, cols in CAT_PREFIXES.items():
            if feature_name in cols:
                display_name = prefix # Use original category name
                break
        # Handle binary features for better explanation
        if feature_name == 'sex': display_name = 'gender'
        if feature_name == 'fbs': display_name = 'fasting blood sugar'
        if feature_name == 'exang': display_name = 'exercise-induced angina'

        current_val = final_input_data[feature_name].values[0]
        original_val = prefill_data.get(feature_name, current_val) # Try to get original value if not scaled

        if row['shap_value'] > 0: # Contributes to higher risk (class 1)
            if feature_name in CONT_COLS:
                 explanation_phrases.append(f"an elevated {display_name} value ({original_val:.1f})")
            elif feature_name.startswith('cp_') and original_val == float(feature_name.split('_')[1]):
                explanation_phrases.append(f"a chest pain type of {int(original_val)}")
            elif feature_name.startswith('thal_') and original_val == float(feature_name.split('_')[1]):
                explanation_phrases.append(f"a thalassemia type of {int(original_val)}")
            else:
                explanation_phrases.append(f"an elevated {display_name}")
        else: # Contributes to lower risk (class 0)
            if feature_name in CONT_COLS:
                explanation_phrases.append(f"a lower {display_name} value ({original_val:.1f})")
            elif feature_name.startswith('cp_') and original_val == float(feature_name.split('_')[1]):
                explanation_phrases.append(f"a chest pain type of {int(original_val)}")
            elif feature_name.startswith('thal_') and original_val == float(feature_name.split('_')[1]):
                explanation_phrases.append(f"a thalassemia type of {int(original_val)}")
            else:
                explanation_phrases.append(f"a lower {display_name}")

    full_explanation = "This patient's heart disease risk prediction is primarily influenced by: "
    full_explanation += ", ".join(explanation_phrases) + ". "
    full_explanation += "A medical professional should consider these factors in conjunction with a full clinical assessment for diagnosis."
    st.info(full_explanation)

st.write("The SHAP values indicate the impact of each feature on the model's output for the current prediction.")
